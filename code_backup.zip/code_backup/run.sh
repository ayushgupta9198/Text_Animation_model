python3 running_code_file-new.py \
    --source_video_path "/home/ayush-ai/Music/final/Ali/test_video/127.mp4" \
    --source_audio_path "/home/ayush-ai/Music/final/Ali/audio/file_example_MP3_1MG.mp3" \
    --destination_path "/home/ayush-ai/Music/final/ayush/output1.mp4" \
    --font_file "/home/ayush-ai/Music/final/shadow_fonts/Double_Bubble_shadow.otf" \
    --font_size 60 \
    --font_color "0,0,255" \
    --text_file "/home/ayush-ai/Music/final/text_file.txt" 

