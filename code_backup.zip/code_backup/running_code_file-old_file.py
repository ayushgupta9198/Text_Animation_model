from PIL import ImageFont, ImageDraw, Image
import numpy as np , cv2 , os , time
from numpy.lib.utils import source

def add_audio(source_path, tmp_res_path, res_path, audio_path = "/home/ayush-ai/Music/final/Ali/audio/6.mp3"):
    # extract audio
    if not os.path.exists('/tmp/audio'):
        os.makedirs('/tmp/audio')

    if audio_path is None:
        print("extracting orginal audio.")
        audio_path = "/tmp/audio/output-audio.mp3"
        cmd = f"ffmpeg -y -i {source_path} -vn -acodec copy {audio_path}"
        os.system(cmd)

    #add audio
    # time.sleep(2)
    if os.path.exists(audio_path):
        cmd = f"ffmpeg -y -i {tmp_res_path} -i {audio_path} -c:v copy -c:a aac {res_path}"
    else:
        cmd = f"mv {tmp_res_path} {res_path}"

    os.system(cmd)
    os.system("rm -r  /tmp/audio")
    print("video genereate sucess fully at location : ",res_path)

def get_text(current_frame , txt_len, total_frames):
    change_interval = int(total_frames)/int(txt_len)
    return int(current_frame/change_interval) 

def animated_text(sentences, source_path, res_path):
  
    cap = cv2.VideoCapture(source_path) 
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    fourcc = cap.get(cv2.CAP_PROP_FOURCC)
    tmp_res_path = "/tmp/output.mp4"
    #output vres_pathideo object 
    out = cv2.VideoWriter(tmp_res_path,cv2.VideoWriter_fourcc('M','J','P','G'), 30, (frame_width,frame_height))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    frame_counter = 0
    opa = 0 # for altering opacity of text
    fs = 50 # font size of text
    boolean = True # varablle helps in effects of alternate frames.
    while(True): 
        ret, image = cap.read() # image is frame of videos.


        if not ret:
            if frame_counter <= 10:
                print("something went wrong.")
            break


        # Convert to PIL Image
        cv2_im_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        pil_im = Image.fromarray(cv2_im_rgb).convert('RGBA')
        txt = Image.new("RGBA", pil_im.size, (255,255,255,0))
        draw = ImageDraw.Draw(txt)
        font_path = "/home/ayush-ai/Music/final/Noto_Serif/NotoSerif-Regular.ttf"
        # Choose a font
        font = ImageFont.truetype(font_path, fs)
        if boolean:
            if opa > 255:
                opa = 250

            colors=(255,0,0,opa)
            opa +=6
            # boolean = not(boolean)
            x = int(frame_width/2)
            y = int(frame_height/2)

        else:
            colors=(0,0,255,opa)
            boolean = not(boolean)
            x = int(frame_width/2)
            y = int(frame_height/2)

        # Draw the text
        sentence = sentences[get_text(frame_counter, len(sentences), total_frames)]
        w, h = draw.textsize(sentence, font=font)
        x = int((frame_width-w)/2 )
        y = int((frame_height-h)/2 )
        draw.text((x,y), sentence, font=font, fill=colors)
        # draw.text(xy=(150,102), text=sentence, fill=colors, font=font) #shadow effect
        pil_img = Image.alpha_composite(pil_im, txt)
        cv2_im_processed = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)
        imS = cv2.resize(cv2_im_processed, (frame_width,frame_height)) 
        out.write(imS)
        # cv2.imshow('video', imS)
        frame_counter += 1
        if cv2.waitKey(1) & 0xFF == ord('q'): 
            break

    cap.release() 
    out.release()
    cv2.destroyAllWindows()
    add_audio(source_path, tmp_res_path, res_path) # for adding audio to the video


if __name__ == "__main__":

    with open("/home/ayush-ai/Music/final/text_file.txt", 'r') as f:
        sentences = f.readlines()

    source_path = "/home/ayush-ai/Music/final/test_video/youtube/1.mp4" 
    res_path = "/home/ayush-ai/Music/final/output.mp4"
    animated_text(sentences, source_path, res_path)